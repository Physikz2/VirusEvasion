import React, { useState, useEffect, useCallback } from 'react';
import { GameStatus } from './types';
import { HUD } from './components/HUD';
import { GameCanvas } from './components/GameCanvas';
import { GameOverModal } from './components/GameOverModal';
import { soundManager } from './utils/audio';

const HIGH_SCORE_KEY = 'virus_evasion_best_score_v1';

export default function App() {
  const [gameStatus, setGameStatus] = useState<GameStatus>('idle');
  const [survivalTime, setSurvivalTime] = useState<number>(0);
  const [activeViruses, setActiveViruses] = useState<number>(0);
  const [nextSpawnCountdown, setNextSpawnCountdown] = useState<number>(5.0);
  const [highScore, setHighScore] = useState<number>(0);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Load high score from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(HIGH_SCORE_KEY);
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (!isNaN(parsed) && parsed > 0) {
          setHighScore(parsed);
        }
      }
    } catch {
      // Ignore localStorage restrictions
    }
  }, []);

  // Update high score in storage if beaten
  const updateHighScoreIfBeaten = useCallback(
    (timeMs: number) => {
      if (timeMs > highScore) {
        setHighScore(timeMs);
        setIsNewRecord(true);
        try {
          localStorage.setItem(HIGH_SCORE_KEY, timeMs.toString());
        } catch {
          // Ignore
        }
      } else {
        setIsNewRecord(false);
      }
    },
    [highScore]
  );

  // Handlers for game lifecycle
  const handleStartGame = useCallback(() => {
    soundManager.playStartArpeggio();
    setSurvivalTime(0);
    setIsNewRecord(false);
    setGameStatus('playing');
  }, []);

  const handleGameOver = useCallback(
    (finalTimeMs: number, virusCount: number) => {
      setSurvivalTime(finalTimeMs);
      setActiveViruses(virusCount);
      updateHighScoreIfBeaten(finalTimeMs);
      setGameStatus('gameover');
    },
    [updateHighScoreIfBeaten]
  );

  const handleUpdateStats = useCallback(
    (timeMs: number, activeCount: number, nextSpawnSec: number) => {
      setSurvivalTime(timeMs);
      setActiveViruses(activeCount);
      setNextSpawnCountdown(nextSpawnSec);
      if (timeMs > highScore) {
        setHighScore(timeMs);
        setIsNewRecord(true);
      }
    },
    [highScore]
  );

  const handleToggleSound = useCallback(() => {
    const next = soundManager.toggle();
    setSoundEnabled(next);
  }, []);

  const handleTogglePause = useCallback(() => {
    setGameStatus((prev) => {
      if (prev === 'playing') return 'paused';
      if (prev === 'paused') return 'playing';
      return prev;
    });
  }, []);

  const handleToggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  }, []);

  // Keyboard shortcut listeners (Space for start/retry, Esc/P for pause)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        if (gameStatus === 'idle' || gameStatus === 'gameover') {
          e.preventDefault();
          handleStartGame();
        }
      } else if (e.code === 'Escape' || e.code === 'KeyP') {
        if (gameStatus === 'playing' || gameStatus === 'paused') {
          e.preventDefault();
          handleTogglePause();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameStatus, handleStartGame, handleTogglePause]);

  return (
    <div className="relative w-screen h-screen flex flex-col bg-[#06080d] text-slate-100 overflow-hidden select-none font-cyber">
      {/* Top HUD */}
      <HUD
        survivalTime={survivalTime}
        activeViruses={activeViruses}
        highScore={highScore}
        nextSpawnCountdown={nextSpawnCountdown}
        gameStatus={gameStatus}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onTogglePause={handleTogglePause}
        onToggleFullscreen={handleToggleFullscreen}
      />

      {/* Main Interactive Canvas Area */}
      <main className="relative flex-1 w-full h-full overflow-hidden flex items-center justify-center">
        <GameCanvas
          gameStatus={gameStatus}
          onGameOver={handleGameOver}
          onUpdateStats={handleUpdateStats}
          onStartGame={handleStartGame}
        />

        {/* Game Over Modal Screen */}
        {gameStatus === 'gameover' && (
          <GameOverModal
            survivalTime={survivalTime}
            highScore={highScore}
            isNewRecord={isNewRecord}
            activeViruses={activeViruses}
            onRestart={handleStartGame}
          />
        )}
      </main>

      {/* Bottom Status Ticker Bar */}
      <footer className="w-full px-4 py-1.5 bg-[#070a12] border-t border-cyan-500/15 flex items-center justify-between text-[11px] text-slate-400 font-mono-hud z-10">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-cyan-300 font-semibold">ARENA GRID: NOMINAL</span>
          </div>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden sm:inline text-slate-400">
            HOSTILE REPRODUCTION CYCLE: 5.0 SECONDS
          </span>
        </div>

        <div className="flex items-center gap-4">
          <span className="hidden md:inline text-slate-400">
            AVOID RECTANGULAR INTERSECTIONS
          </span>
          <span className="text-cyan-400/80">[PRESS SPACE TO REBOOT]</span>
        </div>
      </footer>
    </div>
  );
}
