import React from 'react';
import { RefreshCw, Trophy, Skull, Clock, AlertTriangle, Award } from 'lucide-react';
import { formatTime } from './HUD';

interface GameOverModalProps {
  survivalTime: number;
  highScore: number;
  isNewRecord: boolean;
  activeViruses: number;
  onRestart: () => void;
}

function getRating(timeMs: number): { title: string; desc: string; color: string } {
  const sec = timeMs / 1000;
  if (sec >= 90) {
    return {
      title: 'CYBER GHOST // CLASS S',
      desc: 'Legendary neural agility. Unmatched evasive reflexes.',
      color: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/20',
    };
  }
  if (sec >= 60) {
    return {
      title: 'NETRUNNER ELITE // CLASS A',
      desc: 'Superior threat detection and evasive maneuvers.',
      color: 'text-cyan-400 border-cyan-500/40 bg-cyan-950/20',
    };
  }
  if (sec >= 35) {
    return {
      title: 'FIREWALL DEFENDER // CLASS B',
      desc: 'Competent spatial navigation under hostile pressure.',
      color: 'text-amber-400 border-amber-500/40 bg-amber-950/20',
    };
  }
  if (sec >= 15) {
    return {
      title: 'GRID OPERATOR // CLASS C',
      desc: 'Standard reflex response. Continued calibration required.',
      color: 'text-purple-400 border-purple-500/40 bg-purple-950/20',
    };
  }
  return {
    title: 'RECRUIT PROBE // CLASS D',
    desc: 'Core corrupted early. Stay away from walls and corners.',
    color: 'text-red-400 border-red-500/40 bg-red-950/20',
  };
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  survivalTime,
  highScore,
  isNewRecord,
  activeViruses,
  onRestart,
}) => {
  const rating = getRating(survivalTime);

  return (
    <div
      id="game-over-overlay"
      className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-md bg-[#0b0f19] border border-red-500/40 p-6 sm:p-8 rounded-sm shadow-[0_0_50px_rgba(239,68,68,0.3)]">
        {/* Tech decorative corners */}
        <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-red-500" />
        <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-red-500" />
        <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-red-500" />
        <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-red-500" />

        {/* Header Title */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-sm border border-red-500/30 bg-red-950/40 text-red-400 text-xs font-mono uppercase tracking-widest mb-3">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-pulse" />
            Fatal Collision Detected
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-display tracking-wider text-red-500 uppercase drop-shadow-[0_0_12px_rgba(239,68,68,0.6)]">
            Game Over
          </h2>
          <p className="text-xs text-slate-400 font-cyber tracking-widest uppercase mt-1">
            Hostile entity compromised player node
          </p>
        </div>

        {/* Main Survival Score Box */}
        <div className="relative bg-[#070b13] border border-red-500/25 p-4 rounded-sm mb-5 text-center">
          {isNewRecord && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-amber-500 text-black text-[11px] font-bold tracking-widest uppercase flex items-center gap-1 shadow-[0_0_15px_rgba(245,158,11,0.6)]">
              <Trophy className="w-3 h-3" />
              New High Score!
            </div>
          )}

          <div className="text-xs text-slate-400 font-bold uppercase tracking-widest flex items-center justify-center gap-1.5 mb-1">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            Final Survival Time
          </div>
          <div className="text-4xl sm:text-5xl font-extrabold font-mono-hud text-white tracking-wider my-1 drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            {formatTime(survivalTime)}
          </div>
        </div>

        {/* Secondary Metrics Grid */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="bg-[#070b13] border border-slate-800 p-3 rounded-sm flex items-center gap-3">
            <div className="p-2 rounded bg-red-950/40 border border-red-500/20 text-red-400">
              <Skull className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">Threats Spawned</div>
              <div className="text-lg font-bold font-mono-hud text-slate-200">
                {activeViruses} Blocks
              </div>
            </div>
          </div>

          <div className="bg-[#070b13] border border-slate-800 p-3 rounded-sm flex items-center gap-3">
            <div className="p-2 rounded bg-amber-950/40 border border-amber-500/20 text-amber-400">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-slate-400">All-Time Record</div>
              <div className="text-lg font-bold font-mono-hud text-amber-300">
                {formatTime(highScore)}
              </div>
            </div>
          </div>
        </div>

        {/* Threat Level Assessment */}
        <div className={`p-3 rounded-sm border mb-6 flex items-start gap-3 ${rating.color}`}>
          <Award className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-xs font-bold uppercase tracking-wider font-display">
              {rating.title}
            </div>
            <div className="text-[11px] text-slate-300 font-cyber mt-0.5">
              {rating.desc}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button
          id="btn-retry-game"
          onClick={onRestart}
          autoFocus
          className="w-full group relative py-3.5 px-6 rounded-sm bg-gradient-to-r from-red-600 via-rose-600 to-red-500 hover:from-red-500 hover:to-rose-500 text-white font-display font-bold text-base tracking-widest uppercase transition-all duration-200 shadow-[0_0_25px_rgba(239,68,68,0.45)] hover:shadow-[0_0_35px_rgba(239,68,68,0.7)] flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
        >
          <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
          <span>Reboot System [Space]</span>
        </button>
      </div>
    </div>
  );
};
